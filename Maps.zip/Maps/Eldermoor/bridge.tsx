<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="bridge" tilewidth="16" tileheight="16" tilecount="36" columns="9">
 <image source="../Cute_Fantasy_Free/Outdoor decoration/Bridge_Wood.png" width="144" height="64"/>
</tileset>
