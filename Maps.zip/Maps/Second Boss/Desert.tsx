<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="Desert" tilewidth="16" tileheight="16" tilecount="210" columns="14">
 <image source="DesertTileset16x16/Tileset16x16/DesertTilemapBlankBackground.png" width="224" height="240"/>
</tileset>
