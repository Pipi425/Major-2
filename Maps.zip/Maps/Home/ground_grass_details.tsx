<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="ground_grass_details" tilewidth="16" tileheight="16" tilecount="378" columns="21">
 <image source="../../../../../Downloads/main-characters-home-free-top-down-pixel-art-asset/Tiled_files/ground_grass_details.png" width="336" height="288"/>
</tileset>
