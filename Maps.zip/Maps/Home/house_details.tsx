<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="house_details" tilewidth="16" tileheight="16" tilecount="170" columns="10">
 <image source="../../../../../Downloads/main-characters-home-free-top-down-pixel-art-asset/Tiled_files/house_details.png" width="160" height="272"/>
</tileset>
