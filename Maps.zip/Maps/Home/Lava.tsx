<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.1" name="Lava" tilewidth="16" tileheight="16" tilecount="840" columns="56">
 <image source="Top Down Lava Tileset 16x16 Free/FREE TILESET FILES/freelavatileset-Sheet.png" width="896" height="240"/>
</tileset>
